# UI - JulianPahor

SynthCity is my Porject that relates to my GUI Project Documentation. 

I have also included both completed tutorials, The Drag+Drop and Options.

Enjoy!